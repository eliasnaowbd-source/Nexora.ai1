# Nexora AI

Prototipo de plataforma para generar anuncios publicitarios usando la API de Gemini desde un servidor seguro.

## Requisitos
- Node.js 18 o posterior
- Una clave de API de Google AI Studio si quieres generación real con IA

## Ejecutar localmente
1. Descomprime el proyecto.
2. Abre una terminal dentro de la carpeta `nexora-ai`.
3. Ejecuta `npm install`.
4. Copia `.env.example` a un archivo llamado `.env`.
5. En `.env`, reemplaza `pega_tu_clave_aqui` con tu clave de API.
6. Ejecuta `npm start`.
7. Abre `http://localhost:3000`.

Sin clave de API, la interfaz carga pero la generación devuelve un mensaje claro de configuración pendiente.

## Seguridad
- No subas `.env` a GitHub ni compartas tu clave.
- Configura límites de uso y revisa los costos y condiciones vigentes de la API antes de publicar el servicio.
- Este prototipo no incluye autenticación, pagos, base de datos ni límites por usuario. No lo expongas públicamente sin añadir estas protecciones.
