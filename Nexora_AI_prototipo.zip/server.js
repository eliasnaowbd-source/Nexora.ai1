import express from "express";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();
const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/generate", async (req, res) => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "pega_tu_clave_aqui") {
    return res.status(503).json({
      error: "La IA todavía no está conectada. Configura GEMINI_API_KEY en el archivo .env del servidor."
    });
  }

  const { business, product, audience, promotion, platform, tone } = req.body || {};
  if (!business || !product) {
    return res.status(400).json({ error: "Escribe al menos el nombre del negocio y qué quieres promocionar." });
  }

  const prompt = `Eres un director creativo experto en publicidad para pequeños negocios. Escribe en español natural de México.
Crea una campaña para:
Negocio: ${business}
Producto o servicio: ${product}
Público objetivo: ${audience || "Público general"}
Promoción: ${promotion || "Sin promoción especificada"}
Red social: ${platform || "Instagram"}
Tono: ${tone || "Profesional y llamativo"}

Devuelve únicamente JSON válido con estas claves:
{"headlines":["titular 1","titular 2","titular 3"],"copy":"texto publicitario","cta":"llamada a la acción","visual":"idea visual concreta para el diseño","videoScript":"guion de video vertical de 15 a 20 segundos, con escenas y texto en pantalla"}
No inventes descuentos, precios, resultados ni datos que no se hayan proporcionado.`;

  try {
    const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { responseMimeType: "application/json", temperature: 0.8 }
      })
    });
    const data = await response.json();
    if (!response.ok) {
      return res.status(502).json({ error: data?.error?.message || "No se pudo contactar al modelo de IA. Revisa la clave y el modelo configurado." });
    }
    const raw = data?.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("");
    if (!raw) return res.status(502).json({ error: "La IA no devolvió contenido. Inténtalo otra vez." });
    try {
      return res.json(JSON.parse(raw));
    } catch {
      return res.status(502).json({ error: "La respuesta de la IA no llegó en el formato esperado. Inténtalo de nuevo." });
    }
  } catch {
    return res.status(500).json({ error: "No se pudo conectar con el servicio. Revisa tu conexión e inténtalo de nuevo." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Nexora AI disponible en http://localhost:${port}`));
